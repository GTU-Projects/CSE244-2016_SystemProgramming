HW6 - grep from directory

Dir - Dir > Process a.k.a. fork
File - Dir > Thread
Dir - Dir iletişimi shared memory
File - Dir iletişimi message queue